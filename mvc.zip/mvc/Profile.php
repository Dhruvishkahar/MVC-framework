




<?php 
session_start();
// echo $_SESSION['userdata']->fname;

 ?>
 <table border="2" align="center" cellspacing="10" cellpadding="10" style="background:#d9fdff;">
	
	<tr >
		<tr>
			<th>Welcome:<?php echo $_SESSION['userdata']->user_fname;?></th>
			<th align="text-right">  <a href="logout">logout</a> </tH>
		</tr>
		
		<th>id</th>
		<tH> fname </tH>
		<th> email </tH>
		<th> password </tH>
       
			   </tr>

			   

			   		<tr>
			   			<td>  <?php echo $_SESSION['userdata']->user_id;  ?> </td>
			   			<td>  <?php echo $_SESSION['userdata']->user_fname; ?> </td>
			   			<td>  <?php echo $_SESSION['userdata']->user_email; ?> </td>
			   			<td>  <?php echo $_SESSION['userdata']->user_password; ?> </td>
			   				</tr>
			   		
			   		
			   


			

							</table> 