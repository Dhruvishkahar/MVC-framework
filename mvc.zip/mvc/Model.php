<?php
class Model
{
	public $db;
	public function __construct()
	{
		$this->db = new mysqli("localhost","root","","MVC");
		// if($this->db)
		// {
		// 	echo "Database connected";
		// }
		// else
		// {
		// 	echo "Error";
		// }
	}
	public function insert($table,$data)
	{
			$keys  =  implode('`,`',array_keys($data));

			$values = implode("','",array_values($data));

			$sql = "INSERT INTO `$table` (`$keys`) VALUES('$values')";

			return $ex = $this->db->query($sql);
	}
	public function select_all($table)
	{
		$sql = "SELECT * FROM `$table`";
		$ex = $this->db->query($sql);
		if($ex->num_rows<1)
		{
			$r = "No Record Found";
		}
		else
		{
			while ($res = mysqli_fetch_object($ex)) 
			{
					$r[] = $res;
			}
			return $r;
		}
	}
	public function delete($table,$where)
	{
			$condition ="";
			foreach ($where as $key => $value) {
				$condition = $condition."`$key` = '$value'";
			}
			$sql= "DELETE FROM `$table` WHERE $condition";
			return $ex = $this->db->query($sql);
	}
	public function select_where($table,$where)
	{
		$condition = "";
		foreach ($where as $key => $value) {
			$condition = $condition."`$key` = '$value'";

		}
		$sql = "SELECT * FROM `$table` WHERE $condition";
		$ex = $this->db->query($sql);
		while ($res = mysqli_fetch_object($ex)) {
			$r[] = $res;
		}
		return $r;
	}
	public function update($table,$data,$where)
	{
		$condition = "";
		foreach ($where as $key => $value) {
			$condition = $condition."`$key` = '$value'";
		}
		$update = "";
		foreach ($data as $key => $value) {
			$update = $update."`$key` = '$value' ,";
		}
		$update =rtrim($update,",");

		$sql = "UPDATE `$table` SET $update WHERE $condition ";
		return $ex = $this->db->query($sql);
	}
	public function login($table,$where)
	{
		$condition ="";
		foreach ($where as $key => $value) {
			$condition= $condition."`$key` = '$value' AND";
		}
		$condition = rtrim($condition,"AND");

	 	$sql ="SELECT * FROM `$table` WHERE $condition";
		$ex = $this->db->query($sql);
		while ($res = mysqli_fetch_object($ex)) 
		{
			$r[] = $res;
		}
		return $r;
	}
}

?>