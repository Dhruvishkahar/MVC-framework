<?php
include 'Model.php';
class Controller extends Model
{
	public function __construct()
	{
		// echo "Hello ";
		 parent::__construct();
		 switch ($_SERVER['PATH_INFO']) {
		 	case '/Reg':

		 		if(isset($_POST['Registration']))
		 		{
		 			//echo "OKE";
		 			$fname =$_POST['fname'];
					$email = $_POST['email'];
					$password = md5($_POST['password']);

					$data = array("user_fname"=>$fname,"user_email"=>$email,"user_password"=>$password);

					$insert = $this->insert("user",$data);
					//print_r($insert);
					if($insert)
					{
						header('location:Reg');
					}
					else{
						echo "Error";
					}
		 		}
		 		$show = $this->select_all("user");
		 		include 'reg.php';

		 		break;
		 		case '/delete':
		 			$del_id = $_GET['del_id'];
		 			//echo $del_id;
		 			$where = array("user_id"=>$del_id);
		 			//print_r($where);
		 			$delete = $this->delete("user",$where);
		 			if($delete)
		 			{
		 				header('location:Reg');
		 			}
		 			else
		 			{
		 				echo "Are you Record Not delete?";
		 			}
		 			break;
		 			case '/update':
		 				$up_id = $_GET['up_id'];
		 				//echo $up_id;
		 				$where = array("user_id"=>$up_id);
		 				//print_r($where);
		 				$update = $this->select_where("user",$where);
		 				//print_r($update);
		 				if(isset($_POST['update']))
		 				{
		 					$user_id=  $_POST['id'];
		 					$fname =$_POST['fname'];
							$email = $_POST['email'];
							$password = md5($_POST['password']);
							$where = array("user_id"=>$user_id);
							$data = array("user_fname"=>$fname,"user_email"=>$email,"user_password"=>$password);
							$edit = $this->update("user",$data,$where);
							if($edit)
							{
								header('location:Reg');
							}
							else
							{
								echo "Error";
							}

		 				}
		 				include 'update.php';
		 				break;
		 				case '/Login':
		 				if(isset($_POST['Login']))
		 				{
		 					$email = $_POST['email'];
		 					$password = $_POST['password'];

		 					 $where = array("user_email"=>$email,"user_password"=>$password);
		 					 $login = $this->login("user",$where);
		 					//echo "<pre>";
		 					 //print_r($login);

		 					 if(count($login) == 1 )
		 					 {
		 					 	//echo "oke";
		 					 	session_start();
		 					 	$_SESSION['userdata'] = $login[0];
		 					 	header('location:Profile');
		 					 }
		 					 else
		 					 {
		 					 	echo "Check email and password";
		 					 	//header('refresh:3seconds');
		 					 }
		 				}
		 				include 'login.php';
		 					break;
		 					case '/Profile':
		 						include 'Profile.php';
		 						break;
		 						case '/logout':
		 							session_start();
		 							
		 							session_destroy();
		 							header('location:Login');
		 							break;

		 	
		 	default:
		 		echo "<h1 align='center'>Hello Dhruvish kahar Welcome to MVC</h1>";
		 		break;
		 }
	}
}
$obj= new Controller;

?>