<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>
<body>
	<h1 align="center">Welcome to  MVC Login</h1>
	<table align="center" border="1">
<form method="POST" >
	<tr>
	<th><label>Email</label></th>
	<td><input type="email" name="email"></td>
	</tr>
	<tr>
		<th><label>Password</label></th>
		<td><input type="password" name="password"></td>
	</tr>
	<tr>
	<td colspan="2" align="center">	<input type="submit" name="Login" value="Login"></td>
	</tr>
</form>
</table>
</body>
</html>