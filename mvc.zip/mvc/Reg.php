<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
	<h1 align="center">Welcome to MVC Registration</h1>
	<table align="center" border="1">
	<form method="POST" action="">
		<tr>
			<td><label>FirstName</label></td>
			<td><input type="text" name="fname"></td>
		</tr>
		<tr>
			<td><label>email</label></td>
			<td><input type="email" name="email"></td>
		</tr>
		<tr>
			<td><label>password</label></td>
			<td><input type="password" name="password"></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input type="submit" name="Registration" value="Registration"></td>
		</tr>
	</form>
</table>
<h1 align="center">Welcome to MVC Showdata</h1>
<table align="center" border="1" cellpadding="5" cellspacing="5">
	<thead align="center">
		<tr>
			<th>User_Id</th>
			<th>User_FirstName</th>
			<th>User_Email</th>
			<th>User_Password</th>
			<th colspan="2">Action</th>

		</tr>
	</thead>
	<?php  
	if (($show[0] == "No record Found")) 
	{
		   echo "No record Found";
	}
	else
	{
		foreach ($show as $key => $value) 
			{
				?>
					<tbody align="center">
				<tr>
					<td><?php echo $value->user_id;?></td>
					<td><?php echo $value->user_fname;?></td>
					<td><?php echo $value->user_email;?></td>
					<td><?php echo $value->user_password;?></td>
					<td><a href="delete?del_id=<?php echo $value->user_id;?>">Delete</a></td>
					<td><a href="update?up_id=<?php echo $value->user_id;?>">Update</a></td>

				</tr>
					</tbody>	
	<?php }  } ?>






	
	
</table>

</body>
</html>