<!DOCTYPE html>
<html>
<head>
	<title>Update Form</title>
</head>
<body>
	<?php
	foreach ($update as $key => $value) {?>
		<h1 align="center">Welcome to MVC update data</h1>
		<table align="center" border="1">
		<form method="POST">
			<tr>
				<td><label>User_id</label></td>
				<td><input type="text" readonly="" name="id" value="<?php echo $value->user_id;?>"></td>
			</tr>
			<tr>
				<td><label>FirstName</label></td>
				<td><input type="text" name="fname" value="<?php echo $value->user_fname;?>"></td>
			</tr>
			<tr>
				<td><label>email</label></td>
				<td><input type="email" name="email" value="<?php echo $value->user_email;?>"></td>
			</tr>
			<tr>
				<td><label>password</label></td>
				<td><input type="text" name="password" value="<?php echo $value->user_password;?>"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="update" value="update"></td>
			</tr>
 
</form>
</table>
<?php  	}

	?>
	

</body>
</html>